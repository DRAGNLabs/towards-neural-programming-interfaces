#           Data that we can use to train           #
#               our controller network              #
#              (arrays from sentences)              #
#                                                   #
#           Fulda, Brown, Sitze, Robinson           #
#                       DRAGN                       #
#              GPT-2 Controller Project             #
#                     Feb 2020                      #

import numpy as np 
import re
import pickle as pkl
import copy
import pdb
import gc
import random

# from transformers import GPT2Tokenizer, GPT2Model
from transformers import GPT2Tokenizer, GPT2LMHeadModel
import run_generation as rg

import torch
import torch.nn.functional as F

"""
The stuf returned by model is a tuple of length 3
Last element of tuple is all_hidden_states, a list of length 25
Each element of all_hidden_states is a hidden-state tensor of size (1,seq_length,1024)
For many many sentences:
    Take 20-word sentence
    For i in range(20):
        Pass sentence through GPT2
        Take first and last hidden states and concatenate them to BIG_ARRAY
        Get next predicted token from GPT2 and append to sentence
        Make sentence length 20 again by removing first token
Then BIG_ARRAY is size (1,800,1024) (but we may want to reshape it to be (800, 1024, 1))

See terminal for all the code I typed to do this minus the loops
"""

# Get sentence_list
# sentence_list = pkl.load(sentences_file)
# random.shuffle(sentence_list)

# Create model and tokenizer
model = GPT2LMHeadModel.from_pretrained('gpt2-medium')
model.transformer.output_hidden_states = True
tokenizer = GPT2Tokenizer.from_pretrained('gpt2-medium') 
device = torch.device("cpu") 
if torch.cuda.is_available(): 
    model = model.cuda() 
    device = torch.device("cuda") 

DICT_OF_RELATEDNESS = {"cat":["feline", "lion"]}
# BAD_ROWS = [29, 61, 95, 131, 169, 209, 251, 295, 341, 389, 439, 491, 545, 601, 659]
BAD_ROWS = [29, 59, 89, 119, 149, 179, 209, 239, 269, 299, 329, 359, 389, 419, 449] 

def create_big_arrays_gpt2(word='cat', word_sentence_pkl="cat_sents", generic_sentence_file="wiki", \
                                num_chunks=90, num_sentences_per_chunk=1000, sent_len=15, num_iters=15, \
                                pkl_name="CAT_IN_sentence_arrays", top_k=1, top_p=.9, temperature=1):

    """
    Cycles through list of sentences provided by pkl files, making a big_array of hidden states
    for each sentence.
    For each sentence we perform:
        Take sentence
        For i in range(num_iters):
            Pass sentence through GPT2
            Take first and last hidden states and concatenate them to big_array
            Get next predicted token from GPT2 and append to sentence
            Make sentence length sent_len again by removing first token
    Then big_array is size (1,2*sent_len*num_iters,1024) 
            (but we may reshape it to be (2*sent_len*num_iters, 1024, 1))

    Params:
        word (str): word in question
        word_sentence_pkl (str): path that leads to pkl file containing word sentences (generated from nate_word_reps.py)
        generic_sentence_file (str): path for text file from which to pull generic sentences
        num_chunks (int): number of "chunks" or number of pickle files we'll write with sentence-array data
        num_sentences_per_chunk (int): number of sentences per "chunk" (per pickle file)
        sent_len (int): required sentence length 
        num_iters (int): number of words to add onto the sentence cyclically as we run it through the GPT2
        pkl_name (str): name for pkl to which we save big_arrays (base name for pkl; will be edited for different pkls)
        top_k (int), top_p (float), temperature (int): for GPT2 use when predicting next word
    Returns:
        (list) list of the form described in Zac's README on the GitHub
            (doesn't actually return this. Several such lists are written to num_chunks different pickle files)
    """

    # num_sentences = num_chunks * num_sentences_per_chunk

    # Shortcuts in arguments
    if word_sentence_pkl == "cat_sents":
        word_sentence_pkl = "/mnt/pccfs/backed_up/n8rob/broke_zac_github/transformers/word_pkls/cat_sentences.pkl"
    if generic_sentence_file == "wiki":
        generic_sentence_file = "/mnt/pccfs/not_backed_up/data/text_corpora/Wikipedia_text_with_periods_clean.txt"

    # Word token indices
    #     We want a list of the tokenizer's numberical representations of different forms of our word
    word_token_indices = tokenizer.encode(word) # list of len 1
    toks_from_sentence = tokenizer.encode("this is "+word) # token different in sentence context
    word_token_indices = word_token_indices + toks_from_sentence[2:len(toks_from_sentence)]
    try: # optional s
        word_token_indices = word_token_indices + tokenizer.encode(word+"s")
        toks_from_sentence = tokenizer.encode("this is "+word+"s")
        word_token_indices = word_token_indices + toks_from_sentence[2:len(toks_from_sentence)]
    except:
        pass
    # Do the same for related words too because why not
    if word in DICT_OF_RELATEDNESS: # see global variable DICT_OF_RELATEDNESS
        for related_word in DICT_OF_RELATEDNESS[word]:
            word_token_indices = word_token_indices + tokenizer.encode(related_word)
            toks_from_sentence = tokenizer.encode("this is "+related_word)
            word_token_indices = word_token_indices + toks_from_sentence[2:len(toks_from_sentence)]
            try: # optional_s
                word_token_indices = word_token_indices + tokenizer.encode(related_word+"s")
                toks_from_sentence = tokenizer.encode("this is "+related_word+"s")
                word_token_indices = word_token_indices + toks_from_sentence[2:len(toks_from_sentence)]
            except:
                passi
    # now word_token_indices should have the tokens for all words related to the word in question

    # Fix pkl_name:
    if ".pkl" not in pkl_name:
        pkl_name = pkl_name + ".pkl"
    pkl_name_base = pkl_name
    
    print("getting general sentences",flush=True)

    # Get general sentences
    gen_sent_dict = {}
    with open(generic_sentence_file,'r') as f:
        # We don't want to loop thru all the sentences: keep track of how many
        iterator = 0
        for line in f:
            if (len(line.split()) < sent_len//3) or (('one' in line) and ('two' in line) and ('zero' in line)) or (len(line.split()) > 150):
                continue # not interest in short or long or nasty sentences
            
            # Now we just get the tokens here instead of in the below loop
            #     Prepare initial tokens....
            tokens = tokenizer.encode(line)

            # Check for feline-ness (if cat is word)
            has_word = False
            for tok_idx in word_token_indices:
                if tok_idx in tokens:
                    has_word = True
                    break
            if has_word: # this means the sentence is feline (if cat is word)
                continue

            # Now constuct the tokens correctly
            tokens = torch.tensor(tokens, dtype=torch.long, device=device) 
            # Make the sentence length sent_len (15)
            tokens = tokens[-sent_len:]
            tokens = tokens.unsqueeze(0).repeat(1, 1) 
            tokens = tokens.cuda()

            # append to dict
            gen_sent_dict[line] = tokens
            
            # We only want 4 * num_sentences sentences
            iterator += 1
            if iterator >= 4* num_chunks * num_sentences_per_chunk:
                break

    # Then we take the first num_sentences after shuffling
    gen_sent_keys_temporary = list(gen_sent_dict.keys())
    random.shuffle(gen_sent_keys_temporary)
    gen_sent_keys_smaller = gen_sent_keys_temporary[:num_chunks*num_sentences_per_chunk]
    # make it smaller
    gen_sent_dict_smaller = {k:gen_sent_dict[k] for k in gen_sent_keys_smaller}
    gen_sent_dict = gen_sent_dict_smaller

    print("getting "+word+" sentences",flush=True)
    
    # Get word sentence_list: much easier than the above loop; we'll save finding tokens for bottom loop
    with open(word_sentence_pkl,'rb') as f:
        word_sent_list = pkl.load(f)[0]
    # And clean it? NOTE: this will mean we gotta decrease num_sentences, or we'll have unbalanced data
    filtered_word_sent_list = []
    for i, sent in enumerate(word_sent_list):
        if (len(sent.split()) < sent_len//3) or (('one' in sent) and ('two' in sent) and ('zero' in sent)) or (len(sent.split()) > 150):
            pass # Don't collect sentences with these ^ properties. We don't want them
        else: 
            filtered_word_sent_list.append(sent)
    word_sent_list = filtered_word_sent_list # Keep only nice sentences
    # shuffle now
    # random.shuffle(word_sent_list) # NOT NECESSARY HA HA

    """NOW WE ACTUALLY BEGIN MAKING THE ARRAYS"""

    # PREP FOR GENERIC SENTENCES

    # get generic label
    generic_label = torch.zeros(1,1024,1)
    generic_label[0,-1,0] = 1 # GPT2 position has a 1
    generic_label = generic_label.cuda()

    # loop thru dict keys
    gen_sent_dict_keys = list(gen_sent_dict.keys())
    random.shuffle(gen_sent_dict_keys)

    # AND PREP FOR WORD SENTENCES

    # get word label
    word_label = torch.zeros(1,1024,1)
    word_label[0,0,0] = 1
    word_label[0,-1,0] = 1
    word_label = word_label.cuda()

    #print("access gen_sent_dict_keys and word_sent_list")
    #pdb.set_trace()

    """Now we begin the massive loop of a lifetime...---...---...---...---...---...---...---...---...---...---"""

    for II in range(num_chunks):

        start_point = II*num_sentences_per_chunk
        end_point = start_point + num_sentences_per_chunk

        # Get our pkl_names right 
        pkl_name = pkl_name_base[:-4] + "_" + str(II) + ".pkl"

        # ~~~ FIRST WORD SENTENCES ~~~~~~~~~~~~~~~~~~~~~~~~

        print("beginning "+word+" loop "+str(II)+"/"+str(num_chunks),flush=True)

        # Initialize pickle object 
        data_list = []
        with open(pkl_name,'wb') as f:
            pkl.dump(data_list,f)

        # keep track of number we need to skip
        num_skipped = 0

        for I, sent in enumerate(word_sent_list[start_point:end_point]):
             
            big_array = []

            # Prepare initial tokens
            tokens = tokenizer.encode(sent)
            # Make the sentence length 15
            #           (Do this in a smart way so we don't lose feline-ness if we can, when word is cat)
            # tokens = tokens[-sent_len:]
            for tok_idx in word_token_indices:
                if tok_idx in tokens:
                    start_index = tokens.index(tok_idx)
                    if len(tokens) > start_index+sent_len: # if token is not in final sent_len tokens
                        tokens = tokens[start_index:start_index+sent_len]
                    else:
                        tokens = tokens[-sent_len:]
                    break # break this small loop; we good
            
            # Even if those words could not be found for whatever reason, make sure we have the right length
            tokens = tokens[-sent_len:]
            
            # we only want the sent to be what we are actually considering the sent
            sent = tokenizer.decode(tokens) + " \\*/" # add special symbol to show where GPT2 starts
             
            # if len(tokens) < sent_len: # SKIPPING SHORTER SENTENCES: ARCHAIC PRACTICE
            #    num_skipped += 1
            #    # print here since we won't get to later on
            #    if I % (num_sentences_per_chunk//20) == 0:
            #        percentage = 5 * I//(num_sentences_per_chunk//20)
            #        print("{}%".format(percentage),end=" ",flush=True)
            #    continue
            
            # Format tokens right
            tokens = torch.tensor(tokens, dtype=torch.long, device=device) 
            tokens = tokens.unsqueeze(0).repeat(1, 1) 
            tokens = tokens.cuda()

            num_tokens_needed = sent_len - tokens.shape[1]
            
            # We loop through twenty times now
            for i in range(num_iters+num_tokens_needed):

                # Now run the model
                hidden_states, presents, all_hiddens = model(input_ids=tokens) # all_hiddens is a list of len
                                                                # 25 with tensors of shape 
                                                                # (1,15,1024), where 15 is sent_len
                
                # Add to big_array
                if tokens.shape[1] >= sent_len:
                    big_array.append(all_hiddens[0].data)
                    big_array.append(all_hiddens[-1].data[:,:-1,:]) # get rid of the infs

                # Now we add the new token to the list of tokens
                next_token_logits = hidden_states[0,-1,:] # This is a very long vector
                filtered_logits = rg.top_k_top_p_filtering(next_token_logits, top_k=top_k, top_p=top_p)
                next_token = torch.multinomial(F.softmax(filtered_logits, dim=-1), num_samples=1)
                next_token_list = next_token.tolist()
                next_word = tokenizer.decode(next_token_list)
                sent = sent + " " + next_word
                
                # ...update list of tokens
                if tokens.shape[1] < sent_len:
                    tokens = torch.cat((tokens,next_token.unsqueeze(0)),dim=1).cuda()
                else:
                    tokens = torch.cat((tokens[:,1:],next_token.unsqueeze(0)),dim=1).cuda()
            #print(sent,flush=True) # NOTE: This is a temporary line to see the sentences GPT-2 is making!
            #pdb.set_trace()
            # Now the big_array is a list of length 40 (num_iters*2) of tensors with shape (1,20,1024)
            big_array = torch.cat(big_array, dim=1)
            big_array = big_array.permute(1,2,0) # shape is (2*sent_len*num_iters, 1024, 1) now
            # Add the label on as the first row 
            # big_array = torch.cat((word_label,big_array),dim=0) NOTE: maybe not necessary?

            # We want to save this big_array 
            data_list.append([big_array.cpu().numpy(), word_label.cpu().numpy(), [], "gpt2", {}, sent])
            del big_array # get this off of the GPU, thank you very much!

            # These two blocks of code are just for printing stuff and pickle-writing

            if I % (num_sentences_per_chunk//20) == 0:
                percentage = 5 * I//(num_sentences_per_chunk//20)
                print("{}%".format(percentage),end=" ",flush=True)

            if I % 400 == 399:
                print("|",end=" ",flush=True)
                with open(pkl_name,'wb') as f:
                    pkl.dump(data_list,f)

        print(" ",flush=True) 
        
        # ~~~ NOW THE GENERIC SENTENCES ~~~~~~~~~~~~~~~~~~~~~

        print("beginning generic loop "+str(II)+"/"+str(num_chunks),flush=True)

        # Initialize pickle object 
        with open(pkl_name,'wb') as f:
            pkl.dump(data_list,f)

        for I, sent in enumerate(gen_sent_dict_keys[start_point:end_point-num_skipped]): 
            # (subtract off number skipped to keep training sets equal size for each class)

            big_array = []

            tokens = gen_sent_dict[sent]
            sent = tokenizer.decode(tokens[0].tolist()) + " \\*/" # same as before
        
            num_tokens_needed = sent_len - tokens.shape[1]

            # We loop through twenty times now
            for i in range(num_iters+num_tokens_needed):

                # Now run the model
                hidden_states, presents, all_hiddens = model(input_ids=tokens) # all_hiddens is a list of len
                                                                # 25 with tensors of shape 
                                                                # (1,15,1024), where 15 is sent_len
                
                # Add to big_array
                if tokens.shape[1] >= sent_len:
                    big_array.append(all_hiddens[0].data)
                    big_array.append(all_hiddens[-1].data[:,:-1,:]) # get rid of the infs 

                # Now we extract the new token and add it to the list of tokens
                next_token_logits = hidden_states[0,-1,:]
                filtered_logits = rg.top_k_top_p_filtering(next_token_logits, top_k=top_k, top_p=top_p)
                next_token = torch.multinomial(F.softmax(filtered_logits, dim=-1), num_samples=1)
                next_token_list = next_token.tolist()
                next_word = tokenizer.decode(next_token_list)
                sent = sent + " " + next_word # we just update this so sent remains accurate for dict
                
                # ...update list of tokens (removing first element)
                if tokens.shape[1] < sent_len:
                    tokens = torch.cat((tokens,next_token.unsqueeze(0)),dim=1).cuda()
                else:
                    tokens = torch.cat((tokens[:,1:],next_token.unsqueeze(0)),dim=1).cuda()

            # Now the big_array is a list of length 40 (num_iters*2) of tensors with shape (1,sent_len,1024)
            # pdb.set_trace()
            big_array = torch.cat(big_array, dim=1)
            big_array = big_array.permute(1,2,0) # shape is (2*sent_len*num_iters, 1024, 1) now

            # We want to save this big_array 
            data_list.append([big_array.cpu().numpy(), generic_label.cpu().numpy(), [], "gpt2", {}, sent])
            del big_array # get this off of the GPU, thank you very much!

            # These next two blocks of code are purely for printing stuff and pickle-writin'

            if I % ((num_sentences_per_chunk-num_skipped)//20) == 0:
                percentage = 5 * I//((num_sentences_per_chunk-num_skipped)//20)
                print("{}%".format(percentage),end=" ",flush=True)

            if I % 400 == 399:
                print("|",end=" ",flush=True)
                with open(pkl_name,'wb') as f:
                    pkl.dump(data_list,f)

        
        # Shuffle those suckers!
        random.shuffle(data_list)
        with open(pkl_name,'wb') as f:
            pkl.dump(data_list,f)
        
        print(" ",flush=True)
        
        del data_list # just make sure it's gone to clear up memory
    
    print(" ")
    print("done")
    
    return 


if __name__ == "__main__":

    create_big_arrays_gpt2()

  

        



